n = 1000;
A = rand(n);
[l,u,P] = lu(A);
A = P*A;
%avoid problem of pivoting

L = eye(n);
U = zeros(n);
tic
for j=1:n-1
    U(j,j:n)=A(j,j:n);
    for i=j+1:n
        L(i,j) = A(i,j)/A(j,j);    
    end        
    A(j+1:n,j+1:n) = Uupdate_mex(L(j+1:n,j),A(j,j+1:n),A(j+1:n,j+1:n));
end
toc

