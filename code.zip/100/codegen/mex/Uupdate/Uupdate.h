//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// Uupdate.h
//
// Code generation for function 'Uupdate'
//

#pragma once

// Include files
#include "rtwtypes.h"
#include "emlrt.h"
#include "mex.h"
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>

// Custom Header Code

#ifdef __CUDA_ARCH__
#undef printf
#endif

// Function Declarations
void Uupdate(const real_T cpu_Lcolj_data[], const int32_T Lcolj_size[1],
             const real_T cpu_Arowj_data[], const int32_T Arowj_size[2],
             const real_T cpu_subAold_data[], const int32_T subAold_size[2],
             real_T cpu_subAnew_data[], int32_T subAnew_size[2]);

// End of code generation (Uupdate.h)
