function subAnew = Uupdate(Lcolj,Arowj,subAold) %#codegen
%input: L_ij<-A_ij/A_jj; A
coder.gpu.kernelfun;
m = size(subAold,1);
subAnew = zeros(m);
for i=1:m
    for j = 1:m
        subAnew(i,j) = subAold(i,j)-Lcolj(i)*Arowj(j);
    end
end
end